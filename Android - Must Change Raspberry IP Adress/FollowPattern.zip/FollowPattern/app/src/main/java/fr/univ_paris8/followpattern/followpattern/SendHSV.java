package fr.univ_paris8.followpattern.followpattern;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;


public class SendHSV extends AppCompatActivity {

    WebView webView = null;
    RadioButton radioButtonImage = null;
    RadioButton radioButtonGreen = null;
    RadioButton radioButtonRed = null;
    Button buttonSend = null;
    RadioButton radioButtonSHVGreen = null;
    RadioButton radioButtonSHVRed = null;
    RadioButton radioButtonLow = null;
    RadioButton radioButtonHight = null;
    SeekBar seekBarH = null;
    SeekBar seekBarS = null;
    SeekBar seekBarV = null;
    Button buttonAddH = null;
    Button buttonAddS = null;
    Button buttonAddV = null;
    Button buttonMinH = null;
    Button buttonMinS = null;
    Button buttonMinV = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_hsv);

        webView = findViewById(R.id.webView);
        radioButtonImage = findViewById(R.id.radioButtonImage);
        radioButtonGreen = findViewById(R.id.radioButtonGreen);
        radioButtonRed = findViewById(R.id.radioButtonRed);
        buttonSend = findViewById(R.id.buttonSend);
        radioButtonSHVGreen = findViewById(R.id.radioButtonSHVGreen);
        radioButtonSHVRed = findViewById(R.id.radioButtonSHVRed);
        radioButtonLow = findViewById(R.id.radioButtonLow);
        radioButtonHight = findViewById(R.id.radioButtonHight);
        seekBarH = findViewById(R.id.seekBarH);
        seekBarS = findViewById(R.id.seekBarS);
        seekBarV = findViewById(R.id.seekBarV);
        buttonAddH = findViewById(R.id.buttonAddH);
        buttonAddS = findViewById(R.id.buttonAddS);
        buttonAddV = findViewById(R.id.buttonAddV);
        buttonMinH = findViewById(R.id.buttonMinH);
        buttonMinS = findViewById(R.id.buttonMinS);
        buttonMinV = findViewById(R.id.buttonMinV);


        LoadValues(1, 1);

        buttonAddH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seekBarH.setProgress(seekBarH.getProgress()+1);
            }
        });

        buttonAddS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seekBarS.setProgress(seekBarS.getProgress()+1);
            }
        });

        buttonAddV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seekBarV.setProgress(seekBarV.getProgress()+1);
            }
        });

        buttonMinH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seekBarH.setProgress(seekBarH.getProgress()-1);
            }
        });

        buttonMinS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seekBarS.setProgress(seekBarS.getProgress()-1);
            }
        });

        buttonMinV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                seekBarV.setProgress(seekBarV.getProgress()-1);
            }
        });


        radioButtonSHVGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                radioButtonSHVRed.setChecked(false);
                LoadValues(1, radioButtonLow.isChecked() ? 1 : 2);
            }
        });

        radioButtonSHVRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                radioButtonSHVGreen.setChecked(false);
                LoadValues(2, radioButtonLow.isChecked() ? 1 : 2);
            }
        });

        radioButtonLow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                radioButtonHight.setChecked(false);
                LoadValues(radioButtonSHVGreen.isChecked() ? 1 : 2, 1);
            }
        });

        radioButtonHight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                radioButtonLow.setChecked(false);
                LoadValues(radioButtonSHVGreen.isChecked() ? 1 : 2, 2);
            }
        });

        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChangeReturnImage(2, "");
            }
        });

        radioButtonImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChangeReturnImage(1,"1");
                radioButtonGreen.setChecked(false);
                radioButtonRed.setChecked(false);
            }
        });

        radioButtonGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChangeReturnImage(1, "2");
                radioButtonImage.setChecked(false);
                radioButtonRed.setChecked(false);
            }
        });

        radioButtonRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChangeReturnImage(1, "3");
                radioButtonImage.setChecked(false);
                radioButtonGreen.setChecked(false);
            }
        });

        webView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return (event.getAction() == MotionEvent.ACTION_MOVE);
            }
        });

        webView.getSettings().setUseWideViewPort(true);
        webView.setInitialScale(100);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);

        webView.loadUrl("http://192.168.43.82:5000");

    }

    void ChangeReturnImage(final int operation, final String value)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "http://192.168.43.82/flask/send_values.php";
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams()
            {
                Map<String, String> params = new HashMap<String, String>();
                if(operation == 1)
                {
                    params.put("operation", "changeReturn");
                    params.put("value", value);
                }
                else if(operation == 2)
                {
                    params.put("operation", "setHSV");
                    params.put("GreenOrRed", radioButtonSHVGreen.isChecked() ? "1" : "2");
                    params.put("LowOrHight", radioButtonLow.isChecked() ? "1" : "2");
                    params.put("h", String.valueOf(seekBarH.getProgress()));
                    params.put("s", String.valueOf(seekBarS.getProgress()));
                    params.put("v", String.valueOf(seekBarV.getProgress()));
                }
                return params;
            }
        };
        queue.add(postRequest);
    }
    void LoadValues(final int GreenOrRed,final int LowOrHight)
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        final String url = "http://192.168.43.82/flask/get_values.php?GreenOrRed=" + GreenOrRed + "&LowOrHight=" + LowOrHight;
        StringRequest  getRequest = new StringRequest (Request.Method.GET, url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response) {
                        String[] vals = response.split("\\|");
                        seekBarH.setProgress(Integer.parseInt(vals[0]));
                        seekBarS.setProgress(Integer.parseInt(vals[1]));
                        seekBarV.setProgress(Integer.parseInt(vals[2]));
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );


        queue.add(getRequest);

    }

}
