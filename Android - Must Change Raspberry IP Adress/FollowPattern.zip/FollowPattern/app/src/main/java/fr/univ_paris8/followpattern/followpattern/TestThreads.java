package fr.univ_paris8.followpattern.followpattern;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class TestThreads extends AppCompatActivity implements View.OnClickListener {

    TextView TV = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_threads);

        TV = (TextView) findViewById(R.id.textView);


    }

    public void updateMessage(final String str) {
        TV.post(new Runnable() {
            public void run() {
                TV.setText(str);
            }
        });

        /*runOnUiThread(new Runnable() {
            @Override
            public void run() {
                TV.setText(str);
            }
        });*/
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.button) {
            TV.setText("sss");
            Thread serverThread = new Thread(new MyThread());
            serverThread.start();
        }
    }

    class MyThread implements Runnable {

        @Override
        public void run()
        {
            try
            {


            }catch(Exception ex)
            {

            }
            int i = 0;
            while(true)
            {
                i++;
                String str = "i = " + i;
                updateMessage(str);
            }
        }
    }
}